public interface InterfaceNamePeople {
   public String getName();

}
