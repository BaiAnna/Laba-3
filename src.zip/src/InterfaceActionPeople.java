public interface InterfaceActionPeople {
    public String sleep();
    public String sit();
    public String drink();
    public String see();
    public String getUp();
    public String admire();
    public String find();
    public String eat();
    public String wander();
    public String search();
}
