public  abstract class AbstractHome{
    abstract public String whatHome();
    public String getPlace (String place){
        return place;
    }

}
