public interface InterfaceWeatherConditions {
    public String titleCondition();
}
