public interface InterfaceFood {
    public String whatFood();
}
